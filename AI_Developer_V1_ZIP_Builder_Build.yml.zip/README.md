# AI Developer V1 — ZIP Builder

This repository is designed for a phone-friendly workflow.

## How it works

1. Put your Android project ZIP in the repository.
2. Name it `project.zip`.
3. GitHub Actions extracts the ZIP automatically.
4. The workflow searches for the Android Gradle project.
5. It installs Java/Android tooling.
6. It builds the debug APK.
7. The APK is uploaded as a GitHub Actions artifact.

## Repository layout

```text
.
├── project.zip
└── .github/
    └── workflows/
        └── build.yml
```

The ZIP can contain your Android project at its root or inside one top-level folder.

## Important

The uploaded project ZIP should contain a valid Android Gradle project. A Gradle wrapper is recommended. If there is no wrapper, the workflow attempts to install Gradle and use it.

This V1 builder does not yet modify code with an AI model. It provides the one-ZIP build foundation for the later autonomous AI Developer.
